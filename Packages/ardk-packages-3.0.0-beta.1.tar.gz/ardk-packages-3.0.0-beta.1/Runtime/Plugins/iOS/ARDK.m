@interface ARDK : NSObject

+ (void)loadPlugin;

@end

@implementation ARDK

+ (void)loadPlugin
{
}

@end
