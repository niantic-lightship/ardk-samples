using UnityEngine;

namespace Niantic.Lightship.AR.RCA.Editor.Utilities
{
    internal class _ReadOnlyAttribute : PropertyAttribute
    {
    }
}
