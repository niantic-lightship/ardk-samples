// Copyright 2023 Niantic, Inc. All Rights Reserved.

using System;

namespace Niantic.Lightship.AR.Utilities
{
    // Used for Doxygen generation
    internal class PublicAPIAttribute : Attribute
    {

    }
}
