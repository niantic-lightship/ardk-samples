using System;
using System.Collections.Generic;

using Unity.Collections;
using UnityEngine;
using UnityEngine.SubsystemsImplementation;
using UnityEngine.XR.ARSubsystems;

namespace Niantic.Lightship.AR.Subsystems
{
    /// <summary>
    /// Base class for a persistent anchor subsystem.
    /// </summary>
    /// <remarks>
    /// <para>An anchor is a pose in the physical environment that is tracked by an XR device.
    /// As the device refines its understanding of the environment, anchors will be
    /// updated, allowing you to keep virtual content connected to a real-world position and orientation.</para>
    /// <para>This abstract class should be implemented by an XR provider and instantiated using the <c>SubsystemManager</c>
    /// to enumerate the available <see cref="XRPersistentAnchorSubsystemDescriptor"/>s.</para>
    /// </remarks>
    public class XRPersistentAnchorSubsystem
        : TrackingSubsystem<XRPersistentAnchor, XRPersistentAnchorSubsystem, XRPersistentAnchorSubsystemDescriptor,
            XRPersistentAnchorSubsystem.Provider>
    {
#if DEVELOPMENT_BUILD || UNITY_EDITOR
        private ValidationUtility<XRPersistentAnchor> m_ValidationUtility;
#endif

        /// <summary>
        /// Constructor. Do not invoke directly; use the <c>SubsystemManager</c>
        /// to enumerate the available <see cref="XRPersistentAnchorSubsystemDescriptor"/>s
        /// and call <c>Create</c> on the desired descriptor.
        /// </summary>
        public XRPersistentAnchorSubsystem()
        {

        }

        protected override void OnStart()
        {
            base.OnStart();

#if DEVELOPMENT_BUILD || UNITY_EDITOR
            m_ValidationUtility = new();
#endif
        }

        /// <summary>
        /// Get the changes to anchors (added, updated, and removed) since the last call
        /// to <see cref="GetChanges(Allocator)"/>.
        /// </summary>
        /// <param name="allocator">An allocator to use for the <c>NativeArray</c>s in <see cref="TrackableChanges{T}"/>.</param>
        /// <returns>Changes since the last call to <see cref="GetChanges"/>.</returns>
        public override TrackableChanges<XRPersistentAnchor> GetChanges(Allocator allocator)
        {
            if (!running)
                throw new InvalidOperationException(
                    "Can't call \"GetChanges\" without \"Start\"ing the persistent anchor subsystem!");

            var changes = provider.GetChanges(XRPersistentAnchor.defaultValue, allocator);
            var gotNetworkStatus = provider.GetNetworkStatusUpdate(out var networkStatuses);
            if (gotNetworkStatus)
            {
                // Do something with the status update
            }

            var gotLocalizationStatus = provider.GetLocalizationStatusUpdate(out var localizationStatuses);
            if (gotLocalizationStatus)
            {
                // Do something with the status update
            }
#if DEVELOPMENT_BUILD || UNITY_EDITOR
            m_ValidationUtility.ValidateAndDisposeIfThrown(changes);
#endif
            return changes;
        }

        /// <summary>
        /// Attempts to create a new anchor with the provide <paramref name="pose"/>.
        /// </summary>
        /// <param name="pose">The pose, in session space, of the new anchor.</param>
        /// <param name="anchor">The new anchor. Only valid if this method returns <c>true</c>.</param>
        /// <returns><c>true</c> if the new anchor was added, otherwise <c>false</c>.</returns>
        public bool TryAddAnchor(Pose pose, out XRPersistentAnchor anchor)
        {
            return provider.TryAddAnchor(pose, out anchor);
        }

        /// <summary>
        /// Attempts to remove an existing anchor with <see cref="TrackableId"/> <paramref name="anchorId"/>.
        /// </summary>
        /// <param name="anchorId">The id of an existing anchor to remove.</param>
        /// <returns><c>true</c> if the anchor was removed, otherwise <c>false</c>.</returns>
        public bool TryRemoveAnchor(TrackableId anchorId)
        {
            return provider.TryRemoveAnchor(anchorId);
        }

        /// <summary>
        /// Tries to restore an anchor
        /// </summary>
        /// <param name="anchorPayload">The payload to restore the anchor with</param>
        /// <param name="anchor">The restored anchor</param>
        /// <returns>Whether or not the restoration was successful</returns>
        public bool TryRestoreAnchor(XRPersistentAnchorPayload anchorPayload, out XRPersistentAnchor anchor)
        {
            return provider.TryRestoreAnchor(anchorPayload, out anchor);
        }

        public bool TryLocalize(XRPersistentAnchorPayload anchorPayload,
            out XRPersistentAnchor anchor)
        {
            return provider.TryLocalize(anchorPayload, out anchor);
        }

        /// <summary>
        /// An abstract class to be implemented by providers of this subsystem.
        /// </summary>
        public abstract class Provider : SubsystemProvider<XRPersistentAnchorSubsystem>
        {
            /// <summary>
            /// Invoked to get the changes to anchors (added, updated, and removed) since the last call to
            /// <see cref="GetChanges(XRPersistentAnchor,Allocator)"/>.
            /// </summary>
            /// <param name="defaultAnchor">The default anchor. This should be used to initialize the returned
            /// <c>NativeArray</c>s for backwards compatibility.
            /// See <see cref="Allocator"/>.
            /// </param>
            /// <param name="allocator">An allocator to use for the <c>NativeArray</c>s in <see cref="TrackableChanges{T}"/>.</param>
            /// <returns>Changes since the last call to <see cref="GetChanges"/>.</returns>
            public abstract TrackableChanges<XRPersistentAnchor> GetChanges(XRPersistentAnchor defaultAnchor,
                Allocator allocator);

            /// <summary>
            /// Get a list of network status updates, if any
            /// </summary>
            /// <returns>True if an update is present, false otherwise</returns>
            public abstract bool GetNetworkStatusUpdate(out XRPersistentAnchorNetworkRequestStatus[] statuses);

            /// <summary>
            /// Get a list of localization status updates, if any
            /// </summary>
            /// <returns>True if an update is present, false otherwise</returns>
            public abstract bool GetLocalizationStatusUpdate(out XRPersistentAnchorLocalizationStatus[] statuses);

            /// <summary>
            /// Should create a new anchor with the provided <paramref name="pose"/>.
            /// </summary>
            /// <param name="pose">The pose, in session space, of the new anchor.</param>
            /// <param name="anchor">The new anchor. Must be valid only if this method returns <c>true</c>.</param>
            /// <returns>Should return <c>true</c> if the new anchor was added, otherwise <c>false</c>.</returns>
            public virtual bool TryAddAnchor(Pose pose, out XRPersistentAnchor anchor)
            {
                anchor = default;
                return false;
            }

            /// <summary>
            /// Should remove an existing anchor with <see cref="TrackableId"/> <paramref name="anchorId"/>.
            /// </summary>
            /// <param name="anchorId">The id of an existing anchor to remove.</param>
            /// <returns>Should return <c>true</c> if the anchor was removed, otherwise <c>false</c>. If the anchor
            /// does not exist, return <c>false</c>.</returns>
            public virtual bool TryRemoveAnchor(TrackableId anchorId) => false;

            /// <summary>
            /// Tries to restore an anchor
            /// </summary>
            /// <param name="anchorPayload">The payload to restore the anchor with</param>
            /// <param name="anchor">The restored anchor</param>
            /// <returns>Whether or not the restoration was successful</returns>
            public virtual bool TryRestoreAnchor(XRPersistentAnchorPayload anchorPayload, out XRPersistentAnchor anchor)
            {
                anchor = default;
                return false;
            }

            public virtual bool TryLocalize(XRPersistentAnchorPayload anchorPayload, out XRPersistentAnchor anchor)
            {
                anchor = default;
                return false;
            }
        }
    }
}
