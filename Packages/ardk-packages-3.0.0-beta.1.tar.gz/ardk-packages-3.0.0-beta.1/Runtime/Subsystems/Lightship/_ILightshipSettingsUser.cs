using Niantic.Lightship.AR.Loader;

namespace Niantic.Lightship.AR
{
    internal interface _ILightshipSettingsUser
    {
        public void SetLightshipSettings(LightshipSettings settings);
    }
}
