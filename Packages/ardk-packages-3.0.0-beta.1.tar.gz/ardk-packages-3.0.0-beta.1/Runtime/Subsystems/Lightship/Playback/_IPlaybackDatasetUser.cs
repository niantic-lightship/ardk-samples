namespace Niantic.Lightship.AR.Playback
{
    internal interface _IPlaybackDatasetUser
    {
        public void SetPlaybackDatasetReader(_PlaybackDatasetReader reader);
    }
}
