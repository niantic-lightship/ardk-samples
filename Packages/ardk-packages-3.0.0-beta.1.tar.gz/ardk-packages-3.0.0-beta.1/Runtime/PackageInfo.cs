namespace Niantic.Lightship.AR
{
    static class LightshipPackageInfo
    {
        public const string displayName = "Lightship AR Plugin";
        public const string identifier = "com.nianticlabs.lightship";
    }
}
