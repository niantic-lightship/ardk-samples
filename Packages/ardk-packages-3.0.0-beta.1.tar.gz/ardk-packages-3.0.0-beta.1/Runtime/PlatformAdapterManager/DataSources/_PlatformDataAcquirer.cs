using System;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

namespace Niantic.Lightship.AR.PlatformAdapterManager
{
    /// Adapter that connects to all data sources that the PlatformAdapterManager (PAM) needs.
    /// Drives the PAM lifecycle through the OnUpdate Action.
    internal abstract class _PlatformDataAcquirer : IDisposable
    {
        public abstract bool TryToBeReady();

        public abstract bool TryGetCameraFrame(out XRCameraFrame frame);

        public abstract bool TryGetCameraPose(out Matrix4x4 pose);

        public abstract bool TryGetImageResolution(out Resolution resolution);

        public abstract bool TryGetCpuImage(out XRCpuImage cpuImage);

        public abstract bool TryGetGpuImage(out Texture2D gpuImage);

        public abstract bool TryGetCpuDepthImage(out XRCpuImage cpuDepthImage, out XRCpuImage cpuDepthConfidenceImage);

        public abstract bool TryGetGpuDepthImage(out Texture2D gpuDepthImage, out Texture2D gpuDepthConfidenceImage);

        public virtual DeviceOrientation GetDeviceOrientation()
        {
            return DeviceOrientation.Portrait;
        }

        public abstract TrackingState GetTrackingState();

        public abstract bool TryGetCameraIntrinsics(out XRCameraIntrinsics intrinsics);

        public abstract bool TryGetGpsLocation(out GpsLocation gps);

        public abstract bool TryGetCompass(out CompassData compass);

        public virtual void Dispose()
        {
        }
    }
}
